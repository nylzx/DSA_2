# Group 5 DSA S2101

## About

For our Discrete Structures and Algorithms Class

## Getting Started

### Prerequisites

- Java SDK17
- IDE preferably Netbeans
- PostgresSQL DB
- pgAdmin4

### Development Process

- If you are not familiar yet with Git, you can view this 20-minute video for beginners: <https://youtu.be/IHaTbJPdB-s?si=AHDFHDtovD1wjAlS>
- Key concepts to understand:  Git pull, add, commit, push, branching, and merging tasks.
- We will use one codebase, meaning we need to decide how we structure our packages, naming conventions (variables, methods) and "style" of writing code.
- The `main` branch in Github repository will always be our latest running version of the application. You should create a feature branch for the new code you are working on (feature/addNewEmprecord )
  - Features are developed in a branch, following the format `feature/[task description]`
  - Defects are fixed in a branch following the following format `defect/[issue description]`
- Defensive Coding: Catch errors where they happen, instead of having the entire application break if an error happens.
- Save, Commit, Push as often as possible to avoid loss of work due to system failures.
- For now, I will be the reviewer and approver of all `Merge request` to `main` branch to avoid code breakage.